-- CreateTable
CREATE TABLE "Event" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "externalId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "description" TEXT,
    "category" TEXT NOT NULL,
    "date" DATETIME NOT NULL,
    "time" TEXT,
    "venue" TEXT NOT NULL,
    "city" TEXT NOT NULL,
    "minPrice" REAL,
    "maxPrice" REAL,
    "imageUrl" TEXT,
    "ticketUrl" TEXT NOT NULL,
    "performerName" TEXT,
    "isKidsEvent" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "lastSynced" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "CompetitorMatch" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "eventId" TEXT NOT NULL,
    "competitorName" TEXT NOT NULL,
    "competitorUrl" TEXT NOT NULL,
    "matchScore" REAL NOT NULL,
    "checkedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" DATETIME NOT NULL,
    CONSTRAINT "CompetitorMatch_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "YouTubeVideo" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "eventId" TEXT NOT NULL,
    "videoId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "thumbnailUrl" TEXT NOT NULL,
    "channelTitle" TEXT NOT NULL,
    "checkedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" DATETIME NOT NULL,
    CONSTRAINT "YouTubeVideo_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "SearchLog" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "date" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "queryType" TEXT NOT NULL,
    "queriesUsed" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "SyncLog" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "syncedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "eventsTotal" INTEGER NOT NULL,
    "eventsNew" INTEGER NOT NULL,
    "eventsUpdated" INTEGER NOT NULL,
    "eventsRemoved" INTEGER NOT NULL,
    "status" TEXT NOT NULL,
    "errorMessage" TEXT
);

-- CreateIndex
CREATE UNIQUE INDEX "Event_externalId_key" ON "Event"("externalId");

-- CreateIndex
CREATE UNIQUE INDEX "Event_slug_key" ON "Event"("slug");

-- CreateIndex
CREATE INDEX "Event_category_idx" ON "Event"("category");

-- CreateIndex
CREATE INDEX "Event_date_idx" ON "Event"("date");

-- CreateIndex
CREATE INDEX "Event_isKidsEvent_idx" ON "Event"("isKidsEvent");

-- CreateIndex
CREATE INDEX "CompetitorMatch_eventId_idx" ON "CompetitorMatch"("eventId");

-- CreateIndex
CREATE INDEX "CompetitorMatch_expiresAt_idx" ON "CompetitorMatch"("expiresAt");

-- CreateIndex
CREATE UNIQUE INDEX "CompetitorMatch_eventId_competitorName_key" ON "CompetitorMatch"("eventId", "competitorName");

-- CreateIndex
CREATE INDEX "YouTubeVideo_eventId_idx" ON "YouTubeVideo"("eventId");

-- CreateIndex
CREATE UNIQUE INDEX "YouTubeVideo_eventId_videoId_key" ON "YouTubeVideo"("eventId", "videoId");

-- CreateIndex
CREATE INDEX "SearchLog_date_idx" ON "SearchLog"("date");
