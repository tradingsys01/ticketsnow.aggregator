-- CreateTable
CREATE TABLE "VideoComment" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "youtubeVideoId" TEXT NOT NULL,
    "videoId" TEXT NOT NULL,
    "commentId" TEXT NOT NULL,
    "authorName" TEXT NOT NULL,
    "authorChannelId" TEXT,
    "authorProfileUrl" TEXT,
    "textDisplay" TEXT NOT NULL,
    "likeCount" INTEGER NOT NULL DEFAULT 0,
    "publishedAt" DATETIME NOT NULL,
    "updatedAt" DATETIME NOT NULL,
    "parentCommentId" TEXT,
    "isReply" BOOLEAN NOT NULL DEFAULT false,
    "checkedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" DATETIME NOT NULL,
    CONSTRAINT "VideoComment_youtubeVideoId_fkey" FOREIGN KEY ("youtubeVideoId") REFERENCES "YouTubeVideo" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE UNIQUE INDEX "VideoComment_commentId_key" ON "VideoComment"("commentId");

-- CreateIndex
CREATE INDEX "VideoComment_youtubeVideoId_idx" ON "VideoComment"("youtubeVideoId");

-- CreateIndex
CREATE INDEX "VideoComment_videoId_idx" ON "VideoComment"("videoId");

-- CreateIndex
CREATE INDEX "VideoComment_expiresAt_idx" ON "VideoComment"("expiresAt");

-- CreateIndex
CREATE INDEX "VideoComment_parentCommentId_idx" ON "VideoComment"("parentCommentId");
